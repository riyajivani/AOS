#include <stdio.h>
#include <math.h>

int main() {
    double num = 27.0; // Replace with the desired number
    double result = cbrt(num);

    printf("Cube Root of %.2f: %.2f\n", num, result);

    return 0;
}

