#include <stdio.h>
#include <math.h>

int main() {
    double num = 25.0;
    double result = sqrt(num);

    printf("Square Root of %.2f: %.2f\n", num, result);

    return 0;
}

