#include<stdio.h>

int main()
{
    int a,b;
    printf("enter two numbers\n");
    scanf("%d %d",&a,&b);
    printf("substraction of %d and %d is %d\n",a,b,a-b);
    return 0;
}
